<?php $__env->startSection('content'); ?>
<input type="" name="">
<div id="askRes">----</div>
<div class="card-body">
	<?php echo $__env->make('errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<form id="addTask" action="<?php echo e(url('task')); ?>" method="POST" class="form-horizontal">

		    <?php echo e(csrf_field()); ?>

		
		<div class="row">
			<div class="form-group">
				<label for="Task" class="col-3 control label">Task</label>
				<div class="row">
					<div class="col-6">
						<input type="text" name="name" id="task-name" class="form-control">
					</div>
					<div class="col-6">
						<button type="submit" class="btn btn-success">Add Task</button>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>

	<div class="card">
		<div class="card-heading">
			Current tasks
		</div>
		<div class="card-body">
			<div id="delRes"></div>
			<table class="table table-striped task-table">
				<thead>
					<th>Task</th>
					<th>&nbps;</th>

					<tbody id="list">
						<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr class="delete-form" data-id="<?php echo e($task->id); ?>">
							<td class="table-text">
								<div><?php echo e($task->name); ?></div>
							</td>
							<td>
									
									<?php echo e(csrf_field()); ?>

									
									<button type="submit" class="btn btn-danger">
										Delete
									</button>

							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</thead>
			</table>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>