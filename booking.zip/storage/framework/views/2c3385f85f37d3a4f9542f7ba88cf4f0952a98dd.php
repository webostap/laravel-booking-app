<!DOCTYPE html>
<html>
	<head>
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">  
		<title></title>
	</head>
	<body>

<div class="container">

	<?php echo $__env->make('errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <table class="centered">
        <thead>
          <tr>
              <th>#</th>
              <th>Дата</th>
              <th>Размер</th>
              <th>Начало</th>
              <th>Окончание</th>
              <th>Имя</th>
              <th>Телефон</th>
              <th>Стол</th>
              <th>Удалить</th>
          </tr>
        </thead>

        <tbody>
        	<?php $__currentLoopData = $reserves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		<?php if($reserve->confrimed): ?>
        			<tr class="light-green accent-1">
        		<?php else: ?>
        			<tr class="">
        		<?php endif; ?>

					<td><b><?php echo e($reserve->id); ?></b></td>
					<td><?php echo e(date('d M', strtotime($reserve->date))); ?></td>
					<td><?php echo e($reserve->table_size); ?></td>
					<td><?php echo e(date('H:i', strtotime($reserve->time_beg))); ?></td>
					<td><?php echo e(date('H:i', strtotime($reserve->time_end))); ?></td>
					<td><?php echo e($reserve->name); ?></td>
					<td><?php echo e($reserve->phone); ?></td>

					<td>
	        		<?php if(!$reserve->confrimed): ?>
	        		<form method="POST" action="/admin/edit/reserves/<?php echo e($reserve->id); ?>" >
		            	<?php echo e(csrf_field()); ?><?php echo e(method_field('PUT')); ?>

		            	<input type="submit" class="btn btn-small" value="Подтвердить">
		            </form>
		            <?php else: ?>
		            <?php echo e($reserve->table->id); ?>

	        		<?php endif; ?>
	        		</td>

		            <td><form method="POST" action="/admin/edit/reserves/<?php echo e($reserve->id); ?>" >
		            	<?php echo e(csrf_field()); ?><?php echo e(method_field('DELETE')); ?>

		            	<input type="submit" class="btn btn-floating red lighten-1" value="X">
		            </form></td>

        		</tr>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
        </tbody>
      </table>
            
<?php echo $reserves->render(); ?>
</div>


	</body></html>