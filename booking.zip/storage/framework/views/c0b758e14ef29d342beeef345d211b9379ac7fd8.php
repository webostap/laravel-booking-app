<?php $__env->startSection('content'); ?>

<ul class="collection with-header">

	<li class="collection-header"><h4>Дни недели</h4></li>

	<?php $__currentLoopData = $weekDays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weekDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<li class="collection-item">
		<div class="flex-center">
			<form class="inline-form" method="POST" action="/admin/edit/weekday/<?php echo e($weekDay->id); ?>" >
				<?php echo e(csrf_field()); ?><?php echo e(method_field('PUT')); ?>


				<p style="width: 20px"><?php echo e($weekDay->name); ?></p>

				<select name="stamp_beg" class="browser-default">
					<?php for($i = 0; $i < 48; $i++): ?>
					<option value="<?php echo e($i); ?>"
						<?php if($i == $weekDay->stamp_beg ): ?>
						selected
						<?php endif; ?>
					><?php echo e(\App\library\LocalTiming::stampToStr($i)); ?></option>
					<?php endfor; ?>
				</select>

				<select name="stamp_end" class="browser-default">
					<?php for($i = 0; $i < 48; $i++): ?>
					<option value="<?php echo e($i); ?>"
						<?php if($i == $weekDay->stamp_end ): ?>
						selected
						<?php endif; ?>
					><?php echo e(\App\library\LocalTiming::stampToStr($i)); ?></option>
					<?php endfor; ?>
				</select>

				<label>
					<input name="day_off" type="checkbox"
						<?php if($weekDay->day_off): ?>
						checked="checked"
						<?php endif; ?>
					/><span>выходной</span>
				</label>

				<input type="submit" class="btn" value="OK" title="сохранить изменения">

			</form>

		</div>

	</li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>

<ul class="collection with-header">

	<li class="collection-header"><h4>Специальные дни</h4></li>

	<?php $__currentLoopData = $specialDays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<li class="collection-item">
		<div class="flex-center">
			<form class="inline-form" method="POST" action="/admin/edit/specialday/<?php echo e($specialDay->id); ?>" >
				<?php echo e(csrf_field()); ?><?php echo e(method_field('PUT')); ?>


				<input type="date" name="date" value="<?php echo e($specialDay->date); ?>">

				<select name="stamp_beg" class="browser-default">
					<?php for($i = 0; $i < 48; $i++): ?>
					<option value="<?php echo e($i); ?>"
						<?php if($i == $specialDay->stamp_beg ): ?>
						selected
						<?php endif; ?>
					><?php echo e(\App\library\LocalTiming::stampToStr($i)); ?></option>
					<?php endfor; ?>
				</select>

				<select name="stamp_end" class="browser-default">
					<?php for($i = 0; $i < 48; $i++): ?>
					<option value="<?php echo e($i); ?>"
						<?php if($i == $specialDay->stamp_end ): ?>
						selected
						<?php endif; ?>
					><?php echo e(\App\library\LocalTiming::stampToStr($i)); ?></option>
					<?php endfor; ?>
				</select>

				<label>
					<input name="day_off" type="checkbox"
						<?php if($specialDay->day_off): ?>
						checked="checked"
						<?php endif; ?>
					/><span>выходной</span>
				</label>

				<input type="submit" class="btn" value="OK" title="сохранить изменения">

			</form>

			<form class="secondary-content" method="POST" action="/admin/edit/specialday/<?php echo e($specialDay->id); ?>" >
				<?php echo e(csrf_field()); ?><?php echo e(method_field('DELETE')); ?>

				<input type="submit" class="red lighten-1 btn" value="X" title="удалить">
			</form>

		</div>

	</li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<li class="collection-item">
		<div class="flex-center">
			<form class="inline-form" method="POST" action="/admin/edit/specialday/" >
				<?php echo e(csrf_field()); ?>


				<input type="date" name="date">

				<select name="stamp_beg" class="browser-default">
					<?php for($i = 0; $i < 48; $i++): ?>
					<option value="<?php echo e($i); ?>">
						<?php echo e(\App\library\LocalTiming::stampToStr($i)); ?>

					</option>
					<?php endfor; ?>
				</select>

				<select name="stamp_end" class="browser-default">
					<?php for($i = 0; $i < 48; $i++): ?>
					<option value="<?php echo e($i); ?>"
						<?php if($i == 40 ): ?>
						selected
						<?php endif; ?>
					><?php echo e(\App\library\LocalTiming::stampToStr($i)); ?>

					</option>
					<?php endfor; ?>
				</select>

				<label>
					<input name="day_off" type="checkbox"><span>выходной</span>
				</label>

				<input type="submit" class="btn" value="добавить">

			</form>

		</div>

	</li>
</ul>

<ul class="collection with-header col sm6">

	<li class="collection-header"><h4>Столы</h4></li>

	<table>
      <tr>
          <th>#</th>
          <th>Тип</th>
          <th>Мест</th>
          <th></th>
      </tr>

	<?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr>
          <td><b><?php echo e($table->id); ?></b></td>
          <td><?php echo e($table->type->name); ?></td>
          <td>(<?php echo e($table->size); ?>)</td>
          <td><form method="POST" action="/admin/edit/tables/<?php echo e($table->id); ?>" >
          	<?php echo e(csrf_field()); ?><?php echo e(method_field('DELETE')); ?>

          	<input type="submit" class="btn btn-small btn-floating red lighten-1" value="x" title="удалить">
          </form></td>
      </tr>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

	<li class="collection-item">
		<div class="flex-center">
			<form class="inline-form" method="POST" action="/admin/edit/tables/" >
				<?php echo e(csrf_field()); ?>


				<select name="size" class="browser-default">
					<?php $__currentLoopData = $tableTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($type->size); ?>">
						<?php echo e($type->name); ?> (<?php echo e($type->size); ?>)
					</option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>

			
				<input type="submit" class="btn" value="добавить">

			</form>

		</div>

	</li>

</ul>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>