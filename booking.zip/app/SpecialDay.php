<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SpecialDay extends Model
{
    public $timestamps = false;
}
