<!DOCTYPE html>
<html>
	<head>
		<link href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
		<link rel="stylesheet" href="<?php echo e(URL::asset('css/style.css')); ?>">
		<title></title>
	</head>
	<body>
		<div class="form__wrapper">
			<div id="result"></div>
			<form id="form" class="form" name="booking">
				<h1>Бронирование стола</h1>
				<h2>Контакты</h2>
				<div class="row">
					<div class="input-field col s12">
						<input id="name" type="text" class="validate">
						<label for="name">Имя</label>
					</div>
				</div>
				<div class="row">
					<div class="input-field col s12">
						<input id="phone" type="text" class="validate">
						<label for="phone">Телефон</label>
					</div>
				</div>
				<h2>Стол</h2>
				<div class="row">
					<div class="input-field col s7">
						<select id="iSize">
							<option value="" selected>Выберете стол</option>
							<?php $__currentLoopData = $formDate['tableTypes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tableType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($tableType->tables()->count()): ?>
								<option value="<?php echo e($tableType->size); ?>"><?php echo e($tableType->name); ?> (<?php echo e($tableType->size); ?>)</option>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					<div class="input-field col s5">
						<select id="iDuration">
							<option value="" selected>Длительность</option>

							<option value="2" style="display: none">1ч</option>
							<option value="4">2ч</option>
							<option value="6">3ч</option>
							<option value="8">4ч</option>
							
						</select>
					</div>
				</div>
				<h2>Время брони</h2>
				<div class="row">
					<div class="input-field col s7">
						<input id="iDate" type="text" class="datepicker">
						<label class="select-dropdown" for="datepicker" class="">Дата</label>
					</div>

					<div id="timePicker" class="input-field col s5">
						<select id="iTime" disabled="true">
							<option value="" selected>Время</option>
						</select>
					</div>
				</div>
				<button id="submit" class="btn waves">Забронировать</button>

		    <?php echo e(csrf_field()); ?>

			</form>
		</div>
		<img src="<?php echo e(URL::asset('images/invalid-name.jpg')); ?>" alt="" class="bg">
		<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8=" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
		<script src="<?php echo e(URL::asset('js/ajax.js')); ?>"></script>

		<script type="text/javascript">

			var freeDays = <?php echo $formDate['freeDays']; ?>;
			var freeDates = <?php echo $formDate['freeDates']; ?>;

			

		</script>
		<script src="<?php echo e(URL::asset('js/main.js')); ?>"></script>
	</body></html>