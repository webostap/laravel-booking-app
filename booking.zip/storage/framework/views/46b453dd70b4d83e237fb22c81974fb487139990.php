<!DOCTYPE html>
<html>
	<head>
		<link href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
		<link rel="stylesheet" href="<?php echo e(URL::asset('css/style.css')); ?>">
		<title></title>
	</head>
	<body>
		<table>
		<form method="POST" action="/admin/select/select_form/">
			<?php echo e(csrf_field()); ?><?php echo e(method_field('PUT')); ?>

		  <select name="cars"  class="browser-default">
		    <option value="1">Volvo XC90</option>
		    <option value="2">Saab 95</option>
		    <option value="3">Mercedes SLK</option>
		    <option value="4">Audi TT</option>
		  </select>
		  <input type="submit" value="Submit">
		</form>
		</table>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

		<script type="text/javascript">


document.addEventListener('DOMContentLoaded', function() {
    // var elems = document.querySelectorAll('select');
    // var instances = M.FormSelect.init(elems);
  });
			

		</script>
	</body></html>